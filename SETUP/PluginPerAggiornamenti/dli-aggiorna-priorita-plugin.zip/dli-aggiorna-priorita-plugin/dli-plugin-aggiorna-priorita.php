<?php
/**
 * Plugin Name: Aggiorna Priorità Progetti
 * Description: Imposta il valore 0 nel campo ACF "priorita" per tutti i progetti che non ce l'hanno.
 * Si disattiva automaticamente dopo l'esecuzione.
 * 
 * Per eseguirlo basta copiarlo nella cartella plugins e attivarlo.
 * Rimuoverlo dopo l'esecuzione.
 * 
 * Version: 1.0
 * Author: Tuo Nome
 */

add_action( 'admin_init', 'dli_aggiorna_priorita_progetti' );

/**
 * Risalva tutti i post di tipo progetto e indirizzo-di-ricreca.
 * Per eseguirlo basta copiarlo nella cartella plugins e attivarlo.
 * Rimuoverlo dopo l'esecuzione.
 * @return true
 */
function dli_aggiorna_priorita_progetti() {
		$args = array(
			'post_type'      => array( 'progetto', 'indirizzo-di-ricerca' ),
			'posts_per_page' => -1,
			'post_status'    => 'any',
			'meta_query'     => array(
				array(
					'key'     => 'priorita',
					'compare' => 'NOT EXISTS',
				)
			),
		);
		$posts = get_posts( $args );

		foreach ( $posts as $post ) {
			update_field( 'priorita', 0, $post->ID );
		}

		add_action('admin_notices', function() use ( $posts ) {
			echo '<div class="notice notice-success"><p>' .
				count($posts) . ' progetti aggiornati con priorità = 0. Plugin disattivato automaticamente.</p></div>';
		});
		// Disattiva il plugin dopo l'esecuzione.
		deactivate_plugins( plugin_basename( __FILE__ ) );
		return true;
}
