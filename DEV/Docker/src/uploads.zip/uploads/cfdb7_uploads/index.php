<?php 
	 // Silence is golden.